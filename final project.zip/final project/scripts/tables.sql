Insert into Location values(101,'Mumbai','Maha',400092);
Insert into Location values(102,'Pune','Maha',400123);
Insert into Location values(103,'Patna','MP',400628);
Insert into Location values(104,'Kanpur','UP',400593);
Insert into Location values(105,'Kolkata','WestB',400236);
Insert into Location values(106,'Nigdi','MP',400638);


 Insert into Programs_Scheduled values(501,'Core Java',103,'13-JUN-2017','13-SEP-2017',6);
 Insert into Programs_Scheduled values(502,'.NET',101,'13-JUN-2017','13-SEP-2017',5);
 Insert into Programs_Scheduled values(503,'SocialAnalytics',104,'13-JUN-2017','13-SEP-2017',5);
  Insert into Programs_Scheduled values(504,'Database',104,'13-JUN-2017','13-SEP-2017',5);

 
 select * from Programs_Scheduled;

Insert into Application values(1001,'Nikhil Pandey','21-NOV-1994','BE',99,'Java Developer','nikhil@gmail.com',501,'accepted');                                                                                                                        Devloper','nikhil@gmail.com',501,'Accepted','20-MAR-2017');
Insert into Application values(1002,'Pranali Sawant','01-SEP-1993','BE',75,'Manager','pranalis@gmail.com',503,'confirmed');
Insert into Application values(1003,'Nehali Pansare','13-FEB-1995','BE',79,'Team Leader','pansaren@ymail.com',502,'accepted');
Insert into Application values(1004,'Pooja Pal','30-JULY-1994','BE',83,'Tester','palpooja@yahoo.com',501,'applied');
Insert into Application values(1005,'Rhitika Shetty','25-DEC-1995','BE',69,'Group Leader','rhitika@gmail.com',503,'accepted');
Insert into Application values(1006,'Amruta Patil','11-MAR-1993','BE',86,'App Developer','amrutap@gmail.com',502,'applied');
Insert into Application values(1007,'Jaini Parikh','13-OCT-1994','BE',59,'Java Devloper','jainip@gmail.com',501,'rejected');
Insert into Application values(1008,'Jenny Parikh','13-OCT-1994','BE',59,'Java Devloper','jeenyp@gmail.com',504,'rejected');
Insert into Application values(1009,'Deepika Parikh','13-OCT-1994','BE',59,'Java Devloper','deepu@gmail.com',504,'accepted');


select * from Application;




Insert into Programs_Offered values('Core Java','Basics of java','IT students/ professionals/ engineers',8,'OCPJP');
  
  Insert into Programs_Offered values('.NET',' The course will train you to build solutions for pc servers, mobile phones and embedded devices.','IT students/ professionals/ engineers',7,'MCTS');

   Insert into Programs_Offered values('SocialAnalytics',' Social and analytics helps organisations to improve customer satisfaction.','Graduates/ post-graduates/ MBA',9,'UCI');

  Insert into Programs_Offered values('Database','Learn concepts and application of database handling with SQL Server 2008.','Engineers/Students/Graduates/Anyone',7,'MCITP');
 
 
 Insert into  Participant values(1,'nikhil@gmail.com',1001,501);
 Insert into  Participant values(2,'pansaren@ymail.com',1003,502);
 Insert into  Participant values(3,'deepu@gmail.com',1009,504);
 Insert into  Participant values(4,'rhitika@gmail.com',1005,503);



 
Insert into  Users values('A202','jaini','admin');
Insert into  Users values('A203','nikhil','mac');
Insert into  Users values('A204','pranali','mac');



 
 
